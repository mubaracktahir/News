package com.mubaracktahir.news.data.network

import okhttp3.Interceptor


/**
 * Created by Mubarak Tahir on 6/14/2020.
 * Mubby inc
 * mubarack.tahirr@gmail.com
 */
interface ConnectivityInterceptor : Interceptor {
}