package com.mubaracktahir.news.utils


/**
 * Created by Mubarak Tahir on 6/13/2020.
 * Mubby inc
 * mubarack.tahirr@gmail.com
 */
object Constants {
    object NewsUrls{
        const val BASE_URL = "https://newsapi.org/v1/"
        const val API_KEY = "46c3fe92f4ad4d9d957161671d120429"
        const val API_KEY_QUERY ="apiKey"
    }

}